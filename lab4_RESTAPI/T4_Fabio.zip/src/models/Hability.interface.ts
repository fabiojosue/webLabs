
export interface Hability {
    id: string,
    name: string,
    description: string
}
