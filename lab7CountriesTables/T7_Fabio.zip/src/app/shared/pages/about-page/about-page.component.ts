import { Component } from '@angular/core';

@Component({
  selector: 'shared-about-page',
  standalone: true,
  imports: [],
  templateUrl: './about-page.component.html',
  styles: ``
})
export class AboutPageComponent {

}
