import { Component } from '@angular/core';

@Component({
  selector: 'shared-contact-page',
  standalone: true,
  imports: [],
  templateUrl: './contact-page.component.html',
  styles: ``
})
export class ContactPageComponent {

}
